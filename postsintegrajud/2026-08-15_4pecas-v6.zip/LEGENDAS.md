# Legendas — 4 peças de teste v6 · 15/08/2026

Copiar e colar inteiro, incluindo hashtags. Ordem dos slides: 1, 2, 3.

---

## 1 · integrajud_inss — EIXO 1 × A6 previdenciários — P04 SÉPIA ESCURO

O cálculo que instrui o acordo quase nunca é conferido. Ele chega pronto, com aparência
de coisa julgada, e o prazo corre por cima dele.

Quatro pontos costumam decidir o valor, e nenhum deles aparece no total.

Salários de contribuição atualizados por índice ou data errados: a base entra menor e
todo o benefício nasce menor, para sempre.

Divisor e período básico de cálculo apurados sobre janela errada alteram a RMI de forma
permanente — não é diferença de um mês, é diferença de todos.

Atrasados sem juros e correção discriminados por competência: sem memória, não há como
saber o que efetivamente foi pago.

Descontos e compensações de benefício anterior lançados em bloco, sem demonstrar de onde
saiu cada parcela.

O cálculo do réu não é prova. É a versão dele da conta. Enquanto ninguém refaz, ela é a
única versão nos autos.

Mande a planilha. Em até 24h úteis eu digo se há diferença a discutir.
https://wa.me/5511977237113 · www.integrajud.com.br

Fábio Rebouças — Contador e Perito Contábil
IntegraJud · Inteligência pericial para advocacia

#periciacontabil #calculosjudiciais #direitoprevidenciario #inss #rmi #assistentetecnico
#liquidacaodesentenca #advocacia #provapericial #revisaodebeneficio

---

## 2 · integrajud_rural — EIXO 2 × A13 agrários — P06 AZUL PETRÓLEO

Na execução de dívida rural, o valor cobrado nasce de uma planilha do próprio credor. Ela
entra nos autos como saldo, e o processo segue por ela.

Quatro pontos mudam esse saldo, e todos ficam no caminho até o número, não no número.

Encargos de inadimplência aplicados sobre o período de normalidade: a taxa do
inadimplemento cobrada antes do vencimento reescreve o contrato inteiro.

Capitalização não pactuada, ou em periodicidade diferente da prevista na cédula, muda a
curva do saldo — não apenas a última parcela.

Prorrogação legal por frustração de safra não considerada: o período que a lei prorroga
volta como atraso que não existiu.

Seguro e taxas embutidos na base de cálculo dos juros, em vez de cobrados à parte.

Saldo devedor não se contesta por impressão. Contesta-se por recálculo, período a período,
com os critérios declarados.

Mande a planilha do banco. Em até 24h úteis eu digo se há diferença.
https://wa.me/5511977237113 · www.integrajud.com.br

Fábio Rebouças — Contador e Perito Contábil
IntegraJud · Inteligência pericial para advocacia

#direitoagrario #creditorural #cedularural #execucao #periciacontabil #calculosjudiciais
#revisaodecontrato #assistentetecnico #advocacia #agronegocio

---

## 3 · integrajud_contas — EIXO 3 × A10 auditoria — P08 CINZA CONCRETO

Aprovar conta apresentada não é o mesmo que conferir conta prestada. A diferença entre as
duas coisas costuma aparecer tarde — em inventário, em curatela, em condomínio, em
associação.

Relatório lista o que o administrador diz que entrou e saiu.

Prestação de contas demonstra cada movimento contra o extrato, na data em que ele ocorreu.

Saldo declarado é um número no fim da página.

Saldo demonstrado é o que sobra depois de conciliar entrada, saída e documento.

Conta sem documento de suporte é declaração. A forma contábil existe justamente para
transformá-la em prova — e é essa forma que o Código exige quando as contas são prestadas
em juízo.

Contas se prestam em forma contábil. O resto é narrativa com números.

Mande a prestação de contas. Em até 24h úteis eu digo o que falta demonstrar.
https://wa.me/5511977237113 · www.integrajud.com.br

Fábio Rebouças — Contador e Perito Contábil
IntegraJud · Inteligência pericial para advocacia

#prestacaodecontas #inventario #curatela #condominio #periciacontabil #auditoria
#formacontabil #advocacia #assistentetecnico #direitocivil

---

## 4 · integrajud_cumprimento — EIXO 4 × A14 personalizados — P05 VERDE PROFUNDO

O prazo do cumprimento de sentença corre sobre a conta da outra parte. Quinze dias, e o
cálculo tem trinta páginas.

Refazer tudo do zero não cabe no prazo. Quatro conferências cabem — e são elas que
costumam concentrar a diferença.

Termo inicial de correção e de juros: citação, evento danoso ou trânsito em julgado mudam
o total sem mudar uma linha visível da conta.

Índice aplicado conforme o título e a fase: trocar o índice altera anos de atualização de
uma vez só.

Base sobre a qual incidem a multa e os honorários do art. 523: se a base já vem inflada,
os 20% acompanham.

Abatimento de valores pagos lançado sem data: pagamento computado na data errada vira
diferença que se acumula até o fim.

Impugnar sem recálculo é discordar. Com recálculo e memória, é demonstrar.

Mande o cálculo. Em até 24h úteis eu digo se há o que impugnar.
https://wa.me/5511977237113 · www.integrajud.com.br

Fábio Rebouças — Contador e Perito Contábil
IntegraJud · Inteligência pericial para advocacia

#cumprimentodesentenca #liquidacao #calculosjudiciais #impugnacao #execucao
#periciacontabil #assistentetecnico #advocacia #processocivil #art523
